import pandas as pd
import datetime
import matplotlib.pyplot as plt
import os

# Load data from CSV files
invest = pd.read_csv("D:\\Users\\schandnani\\Python Case Study\\InvestmentData.csv", encoding='ISO-8859-1')
companies = pd.read_csv("D:\\Users\\schandnani\\Python Case Study\\companies.txt", delimiter='\t', encoding="ISO-8859-1")


# Create a directory to save charts if it doesn't exist
plot_directory = "D:\\Users\\schandnani\\Python Case Study\\charts"
if not os.path.exists(plot_directory):
    os.makedirs(plot_directory)

# Define a function to save and close a plot
def save_and_close_plot(fig, filename):
    plt.savefig(os.path.join(plot_directory, filename))
    plt.close()


# Clean and preprocess data
invest['company_permalink'] = invest['company_permalink'].str.lower()
companies['permalink'] = companies['permalink'].str.lower()
mappings = pd.read_csv("D:\\Users\\schandnani\\Python Case Study\\mapping.csv")
companies_new = companies.copy()
companies_new['category_list'] = companies_new['category_list'].str.split('|').str[0].str.strip()
result = pd.merge(companies_new, mappings, on='category_list', how='left')

# Melt the DataFrame and filter data
columns_to_melt = ['Automotive & Sports', 'Blanks', 'Cleantech / Semiconductors', 
                    'Entertainment', 'Health', 'Manufacturing', 
                    'News, Search and Messaging', 'Others', 
                    'Social, Finance, Analytics, Advertising']
columns_to_keep = [col for col in result.columns if col not in columns_to_melt]
melted_df = pd.melt(result, id_vars=columns_to_keep)
melted_df.dropna(inplace=True)
melted_df = melted_df[melted_df['variable'] != 'Blanks']
melted_df.rename(columns={'variable': 'Sector (from mappings)'}, inplace=True)


companies_new1 = companies.copy()
companies_new1['category_list'] = companies_new1['category_list'].str.split('|').str[0].str.strip()
companies_new1['category_list']  = companies_new1['category_list'].str.split('|').str[0].str.strip()
companies_new1 = companies_new1[['category_list']]
companies_new1 = companies_new1.drop_duplicates(subset='category_list')
result1 = pd.merge(companies_new1, mappings, on='category_list', how='left')

# Get a list of columns to replace, excluding 'category_list'
columns_to_replace = result1.columns.difference(['category_list'])

# Melt the DataFrame to convert columns to rows
result1 = pd.melt(result1, id_vars=['category_list'], value_vars=columns_to_replace, 
                 var_name='Sector (from mappings)', value_name='Value')

# Filter out rows where 'Value' is equal to 1
result1 = result1[result1['Value'] == 1]

# Drop the 'Value' column
result1 = result1[['category_list', 'Sector (from mappings)']]

# Reset the index based on the order of 'category_list' in 'companies_new'
#result = result.set_index(result['category_list']).reindex(companies_new['category_list']).reset_index(drop=True)

result1 = result1.dropna(subset=['category_list', 'Sector (from mappings)'])

# Group the data by 'Sector (from mappings)' and count the occurrences
sector_counts = result1['Sector (from mappings)'].value_counts()

# Create a bar plot for sector counts
plt.figure(figsize=(15, 10))
plt.bar(sector_counts.index, sector_counts.values)
plt.xlabel('Sector (from mappings)', fontsize=20)  # X-axis label
plt.ylabel('Count', fontsize=20)  # Y-axis label
plt.title('Sector Distribution', fontsize=20)  # Title of the plot
plt.xticks(rotation=90, fontsize=20)  # Rotate x-axis labels for better readability
plt.yticks(fontsize=20)  # Increased font size of y-axis tick labels
plt.grid(axis='y', linestyle='--', alpha=0.6)  # Add grid lines to the y-axis
plt.tight_layout()  # Ensure tight layout to prevent clipping labels

# Save and close the plot
save_and_close_plot(plt, 'sector_distribution_plot.png')

# Merge data
merged_data = pd.merge(invest, melted_df, left_on='company_permalink', right_on='permalink', how='left')

# Record the start time
start_time = datetime.datetime.now()

# Calculate total investment amount by funding round type
funding_type_investment = merged_data.groupby('funding_round_type')['raised_amount_usd'].sum()
most_suitable_funding_type = funding_type_investment.idxmax()  # Find the most suitable funding type
funding_type_timestamp = datetime.datetime.now()

# Sort the funding types by total investment amount in ascending order
funding_type_investment_sorted = funding_type_investment.sort_values(ascending=True)

# Create a bar plot for total investment amount by funding type
plt.figure(figsize=(15, 10))
plt.bar(funding_type_investment_sorted.index, funding_type_investment_sorted.values / 1e6)
plt.xlabel('Funding Type', fontsize=20)  # X-axis label
plt.ylabel('Total Investment Amount (M USD)', fontsize=20)  # Y-axis label
plt.title('Total Investment Amount by Funding Type', fontsize=20)  # Title of the plot
plt.xticks(rotation=45, fontsize=20)  # Rotate x-axis labels for better readability
plt.yticks(fontsize=20)  # Increased font size of y-axis tick labels
plt.grid(axis='y', linestyle='--', alpha=0.6)  # Add grid lines to the y-axis
plt.tight_layout()  # Ensure tight layout to prevent clipping labels
save_and_close_plot(plt, 'funding_type_plot.png')  # Save and close the plot

# Calculate total investment amount by country code
country_investment = merged_data.groupby('country_code')['raised_amount_usd'].sum()
top_countries = country_investment.nlargest(5)  # Get the top 5 countries with the most investment
countries_timestamp = datetime.datetime.now()

# Sort the top countries by total investment amount in ascending order
top_countries_sorted = top_countries.sort_values(ascending=True)

# Create a bar plot for total investment amount by country code
plt.figure(figsize=(25, 10))
plt.bar(top_countries_sorted.index, top_countries_sorted.values / 1e6)
plt.xlabel('Country Code', fontsize=20)  # X-axis label
plt.ylabel('Total Investment Amount (M USD)', fontsize=20)  # Y-axis label
plt.title('Total Investment Amount by Country', fontsize=20)  # Title of the plot
plt.xticks(fontsize=20)  # Increased font size of x-axis tick labels
plt.yticks(fontsize=20)  # Increased font size of y-axis tick labels
plt.grid(axis='y', linestyle='--', alpha=0.6)  # Add grid lines to the y-axis
plt.tight_layout()  # Ensure tight layout to prevent clipping labels
save_and_close_plot(plt, 'country_investment_plot.png')  # Save and close the plot

# Calculate total investment amount by sector and select the top 5 performing sectors
sector_investment = merged_data.groupby('category_list')['raised_amount_usd'].sum()
best_sectors = sector_investment.nlargest(5)
sectors_timestamp = datetime.datetime.now()

# Sort the top performing sectors by total investment amount in ascending order
best_sectors_sorted = best_sectors.sort_values(ascending=True)

# Split sector labels into two lines with '\n'
split_labels = [label.replace('|', '\n') for label in best_sectors_sorted.index]

# Create a horizontal bar plot for total investment amount by sector
plt.figure(figsize=(25, 10))
plt.barh(split_labels, best_sectors_sorted.values / 1e6)
plt.xlabel('Total Investment Amount (M USD)', fontsize=20)  # X-axis label
plt.ylabel('Sector', fontsize=20)  # Y-axis label
plt.title('Total Investment Amount by Sector', fontsize=20)  # Title of the plot
plt.xticks(fontsize=20)  # Increased font size of x-axis tick labels
plt.yticks(fontsize=20)  # Increased font size of y-axis tick labels
plt.grid(axis='x', linestyle='--', alpha=0.6)  # Add grid lines to the x-axis
plt.tight_layout()  # Ensure tight layout to prevent clipping labels
save_and_close_plot(plt, 'sector_investment_plot.png')  # Save and close the plot

# Create a directory to save text output
output_directory = "D:\\Users\\schandnani\\Python Case Study\\output"
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Define the path for the text file
output_file_path = os.path.join(output_directory, "summary_output.txt")

# Redirect the standard output to the text file
with open(output_file_path, 'w') as output_file:
    # Create a Markdown-like formatted summary
    output_file.write("# Summary Report\n\n")
    
    # Most Suitable Funding Type
    output_file.write("## Most Suitable Funding Type\n\n")
    output_file.write(f"- **Funding Type: {most_suitable_funding_type}\n\n")

    # Countries with Most Funding
    output_file.write("## Countries with Most Funding\n\n")
    for country, amount in top_countries_sorted.items():
        output_file.write(f"- **Country: {country}\n")
        output_file.write(f"  - **Total Investment Amount: {amount / 1e6:.2f} M USD\n")
    output_file.write("\n")

    # Best-Performing Sectors
    output_file.write("## Best-Performing Sectors\n\n")
    for sector, amount in best_sectors_sorted.items():
        sector_with_line_break = sector.replace('|', '\n')
        output_file.write(f"- **Sector:{sector_with_line_break}\n")
        output_file.write(f"  - **Total Investment Amount: {amount / 1e6:.2f} M USD\n")
    output_file.write("\n")

    # Timestamps
    output_file.write("### Timestamps\n")
    output_file.write(f"- Timestamp for Identifying Funding Type: {funding_type_timestamp}\n")
    output_file.write(f"- Timestamp for Identifying Top Countries: {countries_timestamp}\n")
    output_file.write(f"- Timestamp for Identifying Best-Performing Sectors: {sectors_timestamp}\n")

# Print a message indicating where the output has been saved
print("Code run successful")
print(f"Summary output has been saved to {output_file_path}")
result1.to_csv("D:\\Users\\schandnani\\Python Case Study\\sector_mapping.csv", index=False)