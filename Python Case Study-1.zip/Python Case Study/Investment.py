# Import necessary libraries
import pandas as pd
import datetime
import matplotlib.pyplot as plt
import os

# Read investment and company data from CSV files
invest = pd.read_csv("D:\\Users\\schandnani\\Python Case Study\\InvestmentData.csv", encoding='ISO-8859-1')
companies = pd.read_csv("D:\\Users\\schandnani\\Python Case Study\\companies.txt", delimiter='\t', encoding="ISO-8859-1")

# Convert company_permalink and permalink columns to lowercase for merging
invest['company_permalink'] = invest['company_permalink'].str.lower()
companies['permalink'] = companies['permalink'].str.lower()

# Merge investment and company data based on the 'company_permalink' and 'permalink' columns
merged_data = pd.merge(invest, companies, left_on='company_permalink', right_on='permalink', how='left')

# Create a directory to save plots if it doesn't exist
plot_directory = "D:\\Users\\schandnani\\Python Case Study\\plots"
if not os.path.exists(plot_directory):
    os.makedirs(plot_directory)

# Define a function to save and close a plot
def save_and_close_plot(fig, filename):
    plt.savefig(os.path.join(plot_directory, filename))
    plt.close()

# Record the start time
start_time = datetime.datetime.now()

# Calculate total investment amount by funding round type
funding_type_investment = merged_data.groupby('funding_round_type')['raised_amount_usd'].sum()
most_suitable_funding_type = funding_type_investment.idxmax()  # Find the most suitable funding type
funding_type_timestamp = datetime.datetime.now()

# Sort the funding types by total investment amount in ascending order
funding_type_investment_sorted = funding_type_investment.sort_values(ascending=True)

# Create a bar plot for total investment amount by funding type
plt.figure(figsize=(15, 10))
plt.bar(funding_type_investment_sorted.index, funding_type_investment_sorted.values / 1e6)
plt.xlabel('Funding Type',fontsize = 16)  # X-axis label
plt.ylabel('Total Investment Amount (M USD)',fontsize = 16)  # Y-axis label
plt.title('Total Investment Amount by Funding Type',fontsize = 16)  # Title of the plot
plt.xticks(rotation=45,fontsize=16)  # Rotate x-axis labels for better readability
plt.yticks(fontsize=16)  # Increased font size of y-axis tick labels
plt.grid(axis='y', linestyle='--', alpha=0.6)  # Add grid lines to the y-axis
plt.tight_layout()  # Ensure tight layout to prevent clipping labels
save_and_close_plot(plt, 'funding_type_plot.png')  # Save and close the plot

# Calculate total investment amount by country code
country_investment = merged_data.groupby('country_code')['raised_amount_usd'].sum()
top_countries = country_investment.nlargest(5)  # Get the top 5 countries with the most investment
countries_timestamp = datetime.datetime.now()

# Sort the top countries by total investment amount in ascending order
top_countries_sorted = top_countries.sort_values(ascending=True)

# Create a bar plot for total investment amount by country code
plt.figure(figsize=(25, 10))
plt.bar(top_countries_sorted.index, top_countries_sorted.values / 1e6)
plt.xlabel('Country Code',fontsize = 20)  # X-axis label
plt.ylabel('Total Investment Amount (M USD)',fontsize = 20)  # Y-axis label
plt.title('Total Investment Amount by Country',fontsize = 20)  # Title of the plot
plt.xticks(fontsize=20)  # Increased font size of x-axis tick labels
plt.yticks(fontsize=20)  # Increased font size of y-axis tick labels
plt.grid(axis='y', linestyle='--', alpha=0.6)  # Add grid lines to the y-axis
plt.tight_layout()  # Ensure tight layout to prevent clipping labels
save_and_close_plot(plt, 'country_investment_plot.png')  # Save and close the plot

# Calculate total investment amount by sector and select the top 5 performing sectors
sector_investment = merged_data.groupby('category_list')['raised_amount_usd'].sum()
best_sectors = sector_investment.nlargest(5)
sectors_timestamp = datetime.datetime.now()

# Sort the top performing sectors by total investment amount in ascending order
best_sectors_sorted = best_sectors.sort_values(ascending=True)

# Split sector labels into two lines with '\n'
split_labels = [label.replace('|', '\n') for label in best_sectors_sorted.index]

# Create a horizontal bar plot for total investment amount by sector
plt.figure(figsize=(25, 10))
plt.bar(split_labels, best_sectors_sorted.values / 1e6)
plt.xlabel('Total Investment Amount (M USD)',fontsize = 20)  # X-axis label
plt.ylabel('Sector',fontsize = 20)  # Y-axis label
plt.title('Total Investment Amount by Sector',fontsize = 20)  # Title of the plot
plt.xticks(fontsize=20)  # Increased font size of x-axis tick labels
plt.yticks(fontsize=20)  # Increased font size of y-axis tick labels
plt.grid(axis='x', linestyle='--', alpha=0.6)  # Add grid lines to the x-axis
plt.tight_layout()  # Ensure tight layout to prevent clipping labels
save_and_close_plot(plt, 'sector_investment_plot.png')  # Save and close the plot

# Create a directory to save text output
output_directory = "D:\\Users\\schandnani\\Python Case Study\\output"
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Define the path for the text file
output_file_path = os.path.join(output_directory, "summary_output.txt")

# Redirect the standard output to the text file
with open(output_file_path, 'w') as output_file:
    # Print summary information and write it to the text file
    output_file.write(f"Most Suitable Funding Type: {most_suitable_funding_type}\n")
    output_file.write(f"Countries with Most Funding:\n{top_countries_sorted}\n")
    output_file.write(f"Best-Performing Sectors:\n{best_sectors_sorted}\n")
    output_file.write(f"Timestamp for Identifying Funding Type: {funding_type_timestamp}\n")
    output_file.write(f"Timestamp for Identifying Top Countries: {countries_timestamp}\n")
    output_file.write(f"Timestamp for Identifying Best-Performing Sectors: {sectors_timestamp}\n")

# Print a message indicating where the output has been saved
print(f"Summary output has been saved to {output_file_path}")

